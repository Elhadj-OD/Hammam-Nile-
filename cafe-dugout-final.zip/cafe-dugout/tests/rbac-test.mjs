/**
 * Tests RBAC (navigateur réel) + file d'attente hors-ligne.
 * Lancement : node rbac-test.mjs   (app durcie sur :3300)
 */
import { chromium } from 'playwright'

const BASE = process.env.BASE || 'http://127.0.0.1:3300'
let ok = 0, ko = 0
const check = (label, cond, info = '') => {
  if (cond) { ok++; console.log('  ✅ ' + label + (info ? '  → ' + info : '')) }
  else { ko++; console.log('  ❌ ' + label + (info ? '  → ' + info : '')) }
}

const browser = await chromium.launch()

/* ---------- 1. API sans session ---------- */
{
  const ctx = await browser.newContext()
  const p = await ctx.newPage()
  const r = await p.request.get(BASE + '/api/stats')
  check('anonyme /api/stats → 401', r.status() === 401, 'HTTP ' + r.status())
  const res = await p.goto(BASE + '/pos', { waitUntil: 'domcontentloaded' })
  check('/pos sans session → redirigé vers /login', p.url().includes('/login'), 'HTTP ' + res.status() + ' ' + p.url().replace(BASE, ''))
  await ctx.close()
}

/* ---------- 2. connecté en serveur ---------- */
async function login(email) {
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 900 } })
  const p = await ctx.newPage()
  await p.goto(BASE + '/login', { waitUntil: 'networkidle' })
  await p.fill('input[type=email]', email)
  await p.fill('input[type=password]', 'dugout2025')
  await p.click('button[type=submit]')
  await p.waitForURL('**/pos', { timeout: 15000 }).catch(() => {})
  await p.waitForTimeout(1500)
  return { ctx, p }
}
{
  const { ctx, p } = await login('serveur@dugout.mr')
  check('serveur : connexion OK', p.url().endsWith('/pos'), p.url().replace(BASE, ''))
  const r = await p.request.get(BASE + '/api/stats')
  const body = await r.json()
  check('serveur /api/stats → 403 (pas admin)', r.status() === 403, 'HTTP ' + r.status() + ' ' + (body.message || ''))
  const onglets = (await p.getByRole('button').allInnerTexts()).map(s => s.trim())
  check('serveur : onglets admin (Statistiques) non affichés', !onglets.some(t => /Statistiques|QR des tables/.test(t)), onglets.slice(0, 5).join(' / '))
  check('serveur : onglet Commandes visible', onglets.some(t => /Commandes/.test(t)))
  await ctx.close()
}

/* ---------- 3. connecté en admin ---------- */
{
  const { ctx, p } = await login('admin@dugout.mr')
  const r = await p.request.get(BASE + '/api/stats')
  const body = await r.json()
  check('admin /api/stats → 200', r.status() === 200 && body.ok === true, JSON.stringify(body.stats))
  const txt = await p.locator('body').innerText()
  check('admin : onglet Statistiques visible', txt.includes('Statistiques'))
  await ctx.close()
}

/* ---------- 4. file d'attente hors-ligne ---------- */
{
  const ctx = await browser.newContext({ viewport: { width: 430, height: 900 }, isMobile: true, hasTouch: true })
  // la table est mémorisée sur le téléphone (comportement réel d'un client fidèle)
  await ctx.addInitScript(() => localStorage.setItem('cc_table', 'T09'))
  const p = await ctx.newPage()
  await p.goto(BASE + '/', { waitUntil: 'networkidle' })
  await p.waitForTimeout(900)
  await p.getByRole('button', { name: /Ajouter/i }).first().click()
  await p.waitForTimeout(400)

  // réseau coupé sur la route d'envoi uniquement
  await p.route('**/api/orders', r => r.abort('internetdisconnected'))
  await p.getByRole('button', { name: /Envoyer la commande/i }).last().click()
  await p.waitForTimeout(1500)
  const toastTxt = await p.locator('body').innerText()
  check('coupure réseau : message clair au client', /gardée sur ce téléphone|Réseau coupé/i.test(toastTxt))

  const queued = await p.evaluate(async () => {
    const db = await new Promise(res => { const r = indexedDB.open('cafe-dugout', 1); r.onsuccess = () => res(r.result) })
    return await new Promise(res => { const t = db.transaction('outbox', 'readonly'); const q = t.objectStore('outbox').getAll(); q.onsuccess = () => res(q.result) })
  })
  check('commande écrite dans IndexedDB (file d’attente)', queued.length === 1, '1 entrée, client_ref=' + (queued[0]?.client_ref || '').slice(0, 8) + '…')

  // réseau rétabli -> la file se vide seule
  await p.unroute('**/api/orders')
  await p.evaluate(() => window.dispatchEvent(new Event('online')))
  await p.waitForTimeout(2500)
  const after = await p.evaluate(async () => {
    const db = await new Promise(res => { const r = indexedDB.open('cafe-dugout', 1); r.onsuccess = () => res(r.result) })
    return await new Promise(res => { const t = db.transaction('outbox', 'readonly'); const q = t.objectStore('outbox').getAll(); q.onsuccess = () => res(q.result) })
  })
  check('retour du réseau : file vidée automatiquement', after.length === 0, after.length + ' entrée(s) restante(s)')
  await ctx.close()
}

await browser.close()
console.log(`\n===== ${ok} tests réussis, ${ko} échec(s) =====`)
process.exit(ko ? 1 : 0)
