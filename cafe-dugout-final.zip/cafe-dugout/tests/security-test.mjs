/**
 * Tests de sécurité — appels HTTP réels sur l'application durcie.
 * Lancement : node security-test.mjs   (serveur sur :3300)
 */
import crypto from 'node:crypto'
process.env.TABLE_TOKEN_SECRET = process.env.TABLE_TOKEN_SECRET || 'dev-table-secret-0123456789abcdefghijkl'

const BASE = process.env.BASE || 'http://127.0.0.1:3300'
const MOCK = process.env.MOCK || 'http://127.0.0.1:54321'
const ANON = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.fake-mock-anon-key-for-local-testing-only.abcdefghijklmnop'
const SECRET = 'bankily-secret-0123456789abcdefghijklmn'
const uuid = () => crypto.randomUUID()

let ok = 0, ko = 0
function check(label, cond, info = '') {
  if (cond) { ok++; console.log('  ✅ ' + label + (info ? '  → ' + info : '')) }
  else { ko++; console.log('  ❌ ' + label + (info ? '  → ' + info : '')) }
}
const post = (path, body, headers = {}) =>
  fetch(BASE + path, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: typeof body === 'string' ? body : JSON.stringify(body) })

// --- un produit réel du menu (récupéré sur la base de démo) ----------------
const menuRes = await fetch(MOCK + '/rest/v1/menu_items?select=id,name,price&limit=1', { headers: { apikey: ANON } })
const MENU = (await menuRes.json())[0]
console.log('Produit de test :', MENU.name, MENU.price, 'MRU\n')

/* ================= A. VALIDATION DES ENTRÉES (Zod) ================= */
console.log('A. Validation des entrées')
{
  const valid = { table: 'T05', client_ref: uuid(), items: [{ menu_item_id: MENU.id, qty: 1 }] }

  let r = await post('/api/orders', { ...valid, items: [{ menu_item_id: MENU.id, qty: 1, price: 1 }] })
  let d = await r.json()
  check('prix injecté par le client (price: 1) rejeté', r.status === 400 && d.error === 'validation_error', d.message)

  r = await post('/api/orders', { ...valid, items: [{ menu_item_id: MENU.id, qty: 0 }] })
  d = await r.json()
  check('quantité 0 rejetée', r.status === 400, d.message)

  r = await post('/api/orders', { ...valid, items: [{ menu_item_id: MENU.id, qty: 500 }] })
  d = await r.json()
  check('quantité 500 rejetée', r.status === 400, d.message)

  r = await post('/api/orders', { ...valid, table: 'T05', qr_token: 'abcdefgh-1234' })
  d = await r.json()
  check('table + jeton QR en même temps rejeté', r.status === 400, d.message)

  r = await post('/api/orders', { ...valid, table: 'Z99' })
  d = await r.json()
  check('code de table inventé (Z99) rejeté', r.status === 400, d.message)

  r = await post('/api/orders', { ...valid, items: Array.from({ length: 31 }, () => ({ menu_item_id: MENU.id, qty: 1 })) })
  d = await r.json()
  check('panier de 31 lignes rejeté', r.status === 400, d.message)

  r = await post('/api/orders', 'pas du json')
  check('corps non-JSON rejeté', r.status === 400)

  // CSRF : origine étrangère
  r = await post('/api/orders', valid, { origin: 'https://pirate.example' })
  check('requête d’une autre origine (CSRF) bloquée', r.status === 403)

  // et une commande VALIDE passe
  r = await post('/api/orders', valid)
  d = await r.json()
  check('commande valide acceptée', r.status === 200 && d.ok === true, 'total = ' + (d.order?.subtotal ?? '?') + ' MRU')

  // idempotence : on renvoie la même commande (coupure réseau simulée)
  r = await post('/api/orders', valid)
  d = await r.json()
  check('même client_ref renvoyé → pas de doublon', r.status === 200 && d.order_id === d.order?.id, 'duplicate=' + d.order?.duplicate)
}

/* ================= B. WEBHOOKS DE PAIEMENT ================= */
console.log('\nB. Webhooks de paiement (signature)')
{
  const payload = { event_id: 'evt-' + uuid(), reference: 'REF-' + uuid().slice(0, 8), amount: 250, currency: 'MRU', status: 'paid' }
  const raw = JSON.stringify(payload)
  const ts = Math.floor(Date.now() / 1000)
  const sign = (body, timestamp, secret = SECRET) =>
    crypto.createHmac('sha256', secret).update(`${timestamp}.${body}`).digest('hex')

  let r = await post('/api/payments/webhook/bankily', raw)
  check('sans signature → refusé', r.status === 401)

  r = await post('/api/payments/webhook/bankily', raw, { 'x-bankily-timestamp': String(ts), 'x-bankily-signature': '0'.repeat(64) })
  check('signature inventée → refusé', r.status === 401)

  r = await post('/api/payments/webhook/bankily', raw, { 'x-bankily-timestamp': String(ts), 'x-bankily-signature': sign(raw, ts, 'mauvaise-cle-secrete-0000000000') })
  check('signature calculée avec une autre clé → refusé', r.status === 401)

  r = await post('/api/payments/webhook/bankily', raw, { 'x-bankily-timestamp': String(ts - 3600), 'x-bankily-signature': sign(raw, ts - 3600) })
  check('signature valide mais vieille d’une heure (rejeu) → refusé', r.status === 401)

  // corps modifié après signature
  const tampered = raw.replace('250', '25')
  r = await post('/api/payments/webhook/bankily', tampered, { 'x-bankily-timestamp': String(ts), 'x-bankily-signature': sign(raw, ts) })
  check('montant modifié après signature → refusé', r.status === 401)

  const headers = { 'x-bankily-timestamp': String(ts), 'x-bankily-signature': sign(raw, ts) }
  r = await post('/api/payments/webhook/bankily', raw, headers)
  let d = await r.json()
  check('signature valide → accepté', r.status === 200 && d.ok === true, 'résultat = ' + d.result)

  r = await post('/api/payments/webhook/bankily', raw, headers)
  d = await r.json()
  check('même événement rejoué → traité une seule fois', r.status === 200 && d.duplicate === true)

  r = await post('/api/payments/webhook/inconnu', raw, headers)
  check('opérateur inconnu → 404', r.status === 404)
}

/* ================= C. JETONS QR DE TABLE ================= */
console.log('\nC. Jetons de table signés (QR de session)')
{
  let r = await fetch(BASE + '/api/table/session?s=v1.ZmFrZQ.c2lnbmF0dXJl')
  check('jeton forgé → refusé', r.status === 400)

  const { signTableToken } = await import('../lib/security/qr.js')
  const good = signTableToken('T07', 900)
  r = await fetch(BASE + '/api/table/session?s=' + encodeURIComponent(good))
  let d = await r.json()
  check('jeton valide → table reconnue', r.status === 200 && d.table === 'T07', 'table = ' + d.table)

  const expired = signTableToken('T07', -10)
  r = await fetch(BASE + '/api/table/session?s=' + encodeURIComponent(expired))
  d = await r.json()
  check('jeton expiré → refusé', r.status === 400, d.reason)

  // un jeton T07 ne peut pas désigner T08 : la charge est signée
  const forged = good.split('.')
  const payload = JSON.parse(Buffer.from(forged[1], 'base64url').toString())
  payload.c = 'T08'
  const hacked = forged[0] + '.' + Buffer.from(JSON.stringify(payload)).toString('base64url') + '.' + forged[2]
  r = await fetch(BASE + '/api/table/session?s=' + encodeURIComponent(hacked))
  check('table modifiée dans le jeton → signature invalide', r.status === 400)
}

/* ================= D. LIMITATION DE DÉBIT ================= */
console.log('\nD. Limitation de débit (rafale de commandes)')
{
  const results = []
  for (let i = 0; i < 26; i++) {
    const r = await post('/api/orders', { table: 'T1' + (i % 9 + 1), client_ref: uuid(), items: [{ menu_item_id: MENU.id, qty: 1 }] })
    results.push(r.status)
    if (r.status === 429) await r.json()
  }
  const limited = results.filter(s => s === 429).length
  const accepted = results.filter(s => s === 200).length
  check(`26 commandes d’affilée → ${accepted} acceptées puis blocage`, limited > 0, `${limited} réponses 429`)
  const last = await post('/api/orders', { table: 'T05', client_ref: uuid(), items: [{ menu_item_id: MENU.id, qty: 1 }] })
  check('blocage confirmé après la rafale', last.status === 429, 'retry-after = ' + last.headers.get('retry-after') + 's')
}

console.log(`\n===== ${ok} tests réussis, ${ko} échec(s) =====`)
process.exit(ko ? 1 : 0)
