#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Café Dugout — génération des QR codes des tables.

UTILISATION
-----------
1) Édite BASE_URL ci-dessous avec l'adresse réelle du site (sans paramètre).
2) Lance :  python3 qr/generate_qr.py
3) Récupère :
   - qr/codes/T01.png ... (images individuelles, à coller/partager)
   - qr/codes/T01.svg ...  (vectoriel, qualité maximale pour l'imprimeur)
   - qr/planche-qr.html    (planche A4 à imprimer depuis le navigateur)
   - qr/Cafe-Dugout-QR-Tables.pdf (planche A4 prête à imprimer)

Les jetons (k=...) sont FIXES : ils viennent de qr/tables.json, lui-même
aligné sur le fichier supabase/2_seed.sql. Tant que tu ne régénères pas les
jetons en base, les QR déjà imprimés restent valables.
"""

import json
import os
import html
from pathlib import Path

import segno
from fpdf import FPDF

BASE_URL = "https://cafe-dugout.pages.dev/"   # <-- TA MODIFICATION ICI
BRAND = "Café Dugout"
BRAND_AR = ""
SUB = "Commandez depuis votre téléphone"

ROOT = Path(__file__).resolve().parent
CODES = ROOT / "codes"
CODES.mkdir(exist_ok=True)


def url_for(base: str, code: str, token: str) -> str:
    base = base.rstrip("/") + "/"
    return f"{base}?t={code}&k={token}"


def load_tables():
    data = json.loads((ROOT / "tables.json").read_text(encoding="utf-8"))
    return data["tables"], data.get("base_url", BASE_URL)


def make_images(tables, base_url):
    made = []
    for t in tables:
        url = url_for(base_url, t["code"], t["token"])
        qr = segno.make(url, error="h")            # H = 30 % de tolérance (taches, scotch)
        png = CODES / f"{t['code']}.png"
        svg = CODES / f"{t['code']}.svg"
        qr.save(png, scale=12, border=2, dark="#240b11", light="#ffffff")
        qr.save(svg, scale=10, border=2, dark="#240b11", light="#ffffff")
        made.append({**t, "url": url, "png": png, "svg": svg})
    return made


def make_pdf(cards, out: Path):
    """Planche A4 : 3 colonnes x 7 lignes, cartes arrondies vert/jaune."""
    pdf = FPDF(orientation="P", unit="mm", format="A4")
    pdf.set_auto_page_break(False)
    pdf.set_margins(10, 10, 10)
    pdf.add_page()

    W, H = 210, 297
    margin, gap = 10, 5
    cols, rows = 3, 7
    cw = (W - 2 * margin - (cols - 1) * gap) / cols
    ch = (H - 2 * margin - (rows - 1) * gap) / rows

    for i, c in enumerate(cards):
        r, k = divmod(i, cols)
        x = margin + k * (cw + gap)
        y = margin + r * (ch + gap)

        # carte
        pdf.set_fill_color(36, 11, 17)
        pdf.set_draw_color(217, 180, 63)
        pdf.set_line_width(0.5)
        pdf.rect(x, y, cw, ch, style="DF", round_corners=True, corner_radius=3)

        # titre
        pdf.set_text_color(240, 210, 122)
        pdf.set_font("Helvetica", "B", 11)
        pdf.set_xy(x, y + 1.2)
        pdf.cell(cw, 5, c["label"], align="C")

        # QR
        size = min(cw - 18, ch - 15)
        qx = x + (cw - size) / 2
        qy = y + 7.5
        border = 1.6
        pdf.set_fill_color(255, 255, 255)
        pdf.rect(qx - border, qy - border, size + 2 * border, size + 2 * border, style="F", round_corners=True, corner_radius=1.5)
        pdf.image(str(c["png"]), qx, qy, size, size)

        # pied
        pdf.set_text_color(217, 180, 63)
        pdf.set_font("Helvetica", "", 6.5)
        pdf.set_xy(x + 1, qy + size + 3.2)
        pdf.cell(cw - 2, 4, f"{BRAND} - scannez pour commander", align="C")

    pdf.set_text_color(255, 255, 255)
    pdf.output(str(out))


def make_html(cards, out: Path):
    cell = []
    for c in cards:
        svg = c["svg"].read_text(encoding="utf-8")
        svg = svg.replace("<svg ", '<svg class="q" ', 1)
        cell.append(f"""    <div class="card">
      <div class="lbl">{html.escape(c['label'])}</div>
      <div class="qrw">{svg}</div>
      <div class="brand">{html.escape(BRAND)}<span>{html.escape(BRAND_AR)}</span></div>
    </div>""")

    out.write_text(f"""<!DOCTYPE html>
<html lang="fr"><head><meta charset="utf-8">
<title>QR codes — {html.escape(BRAND)}</title>
<style>
  @page {{ size: A4 portrait; margin: 8mm; }}
  *{{box-sizing:border-box}}
  body{{margin:0;font-family:system-ui,-apple-system,Segoe UI,sans-serif;background:#f4efe6;color:#240b11}}
  .grid{{display:grid;grid-template-columns:repeat(3,1fr);gap:4mm;padding:4mm}}
  .card{{background:#240b11;border:1.2px solid #d9b43f;border-radius:4mm;padding:3mm;text-align:center;
        display:flex;flex-direction:column;align-items:center;justify-content:space-between;min-height:36mm;break-inside:avoid}}
  .lbl{{color:#f0d27a;font-weight:800;font-size:11pt;line-height:1.1}}
  .qrw{{background:#fff;border-radius:2mm;padding:1.5mm;margin:1.5mm 0}}
  .q{{display:block;width:22mm;height:22mm}}
  .brand{{color:#d9b43f;font-size:6.5pt;letter-spacing:.3px}}
  .brand span{{display:block;font-size:7pt}}
  @media print {{ body{{background:#fff}} .grid{{gap:3.5mm;padding:0}} }}
</style></head>
<body>
<div class="grid">
{chr(10).join(cell)}
</div>
</body></html>
""", encoding="utf-8")


def main():
    tables, base_url = load_tables()
    base_url = BASE_URL if BASE_URL else base_url
    cards = make_images(tables, base_url)
    make_pdf(cards, ROOT / "Cafe-Dugout-QR-Tables.pdf")
    make_html(cards, ROOT / "planche-qr.html")
    print(f"{len(cards)} QR générés -> {CODES}")
    print(f"Planche PDF  -> {ROOT / 'Cafe-Dugout-QR-Tables.pdf'}")
    print(f"Planche HTML -> {ROOT / 'planche-qr.html'}")
    print(f"Base URL     : {base_url}")


if __name__ == "__main__":
    main()
