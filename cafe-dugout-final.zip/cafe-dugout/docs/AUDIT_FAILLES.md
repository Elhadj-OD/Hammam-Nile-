# Audit de sécurité — Café Dugout (version `index.html` d'origine)

Fichier audité : `uploads/app.html` (37 Ko, application 100 % côté navigateur, stockage `localStorage`).

Résumé : l'interface est propre, mais **il n'y avait aucune frontière de sécurité** — tout ce qui
compte (codes d'accès, prix, totaux, commandes, rôles) vivait dans le navigateur, donc dans les mains
du client. La version corrigée déplace la confiance vers PostgreSQL (Supabase) : rôles réels,
prix relus en base, RLS, jetons de table.

| # | Faille | Gravité | Corrigée dans |
|---|---|---|---|
| 1 | Codes gérant/admin en clair dans le HTML (`PIN={g:'1234'…}`) | 🔴 Critique | `app/index.html` + Supabase Auth |
| 2 | Totaux et prix calculés (et donc falsifiables) par le navigateur | 🔴 Critique | `place_order_core()` |
| 3 | Aucune authentification des clients, aucune isolation des commandes | 🔴 Critique | RLS + `client_place_order()` |
| 4 | Aucune RLS : une connexion directe à Supabase aurait exposé toutes les tables | 🟠 Élevé | `1_schema.sql` §7 |
| 5 | Table choisissable librement (commander pour la table 12 depuis chez soi) | 🟠 Élevé | jeton `qr_token` + `v_tables_public` |
| 6 | Aucune limite de débit ni de volume (spam de commandes) | 🟠 Élevé | `check_throttle()` + contraintes |
| 7 | Paiement non contrôlé (montant libre, pas de trace de l'encaîneur) | 🟠 Élevé | `staff_record_payment()` |
| 8 | XSS stocké possible (noms, notes, URL d'images injectés dans `innerHTML`) | 🟡 Moyen | `esc()` partout + filtre URL + CSP |
| 9 | Photos en base64 dans `localStorage` (quota 5 Mo, pertes, pas de partage) | 🟡 Moyen | Storage + 2 Mo + types filtrés |
| 10 | Purge de l'historique en un clic, sans rôle ni sauvegarde | 🟡 Moyen | `staff_purge_history()` admin only |
| 11 | Pas d'expiration de session, pas de verrouillage réel | 🟡 Moyen | JWT + `signOut()` + `onAuthStateChange` |
| 12 | Données par appareil (serveur ≠ caisse ≠ cuisine) : commandes perdues | 🟢 Faible | base unique partagée |
| 13 | N° de ticket `C` + timestamp : collisions possibles | 🟢 Faible | `order_no` séquentiel |
| 14 | CDN sans SRI ni CSP (Tailwind en prod) | 🟢 Faible | recommandations §Fin |

---

## 1. 🔴 Codes d'accès en clair dans le navigateur

```js
// AVANT — n'importe qui fait Ctrl+U et lit les codes
const PIN={g:'1234',a:'2240'};
function doLogin(){const v=$('#pin').value;if(v===PIN.a)un.a=1;else if(v===PIN.g)un.g=1;…}
```

Le commentaire du fichier le disait lui-même : « Protection côté navigateur seulement ».
Recherche Google : `site:tonsite "PIN="` → le code admin est public. Et un seul code partagé =
aucune traçabilité (on ne sait pas qui a encaissé quoi).

**Après** — identité et rôle viennent de la base :

```js
const {error}=await sb.auth.signInWithPassword({email,password:pass});
const {data}=await sb.from('staff').select('full_name,role,is_active').eq('id',user.id).maybeSingle();
ME=data;                                   // le rôle est décidé par public.staff, pas par l'écran
const can=l=>!ME?false:(l=='a'?ME.role==='admin':['admin','gerant','serveur','cuisine'].includes(ME.role));
```

Un utilisateur qui modifie le HTML peut afficher les onglets, mais **la base refuse** chaque requête
(RLS + fonctions `security definer` qui revérifient le rôle). Tester le rôle seulement dans l'UI est
cosmétique ; ici il est revérifié côté serveur.

## 2. 🔴 Prix et totaux falsifiables

```js
// AVANT : le navigateur envoie {price:280, qty:2} et le total est calculé côté client
const tot=o=>o.items.reduce((a,i)=>a+i.price*i.qty,0);
```

Un client modifie `price` dans le localStorage (ou dans la requête) → thieboudienne à 1 MRU, ticket
faux, caisse qui ne tombe pas juste.

**Après** — le navigateur n'envoie que des identifiants et des quantités :

```js
await sb.rpc('client_place_order',{p_token:QK,p_items:[{menu_item_id:'…',qty:2,note:null}]});
```

et dans PostgreSQL :

```sql
select * into v_menu from public.menu_items m where m.id = (v_item->>'menu_item_id')::uuid;
insert into public.order_items (order_id,menu_item_id,name_snapshot,unit_price,qty,note)
values (v_order, v_menu.id, v_menu.name, v_menu.price, v_qty, v_note);   -- prix = celui de la base
```

Le sous-total est recalculé par un trigger (`tg_recalc_subtotal`) et `line_total` est une colonne
`generated always as (unit_price*qty)`. **Impossible de payer autre chose que le prix du menu.**

## 3. 🔴 Clients non authentifiés, commandes non isolées

Dans l'ancienne version, « le serveur », c'était le `localStorage` de chaque appareil : aucune donnée
n'était réellement partagée, et dès qu'on branche une vraie base sans précaution, un client pouvait
lire **toutes** les commandes et tous les encaissements.

**Après** :
- `anon` n'a **aucun** `grant` sur `orders`, `order_items`, `payments` (testé : `permission denied`).
- Un client ne peut lire que **sa** table, via `client_open_order(p_token)`.
- Il ne peut qu'**ajouter** des lignes ; il ne peut ni supprimer, ni changer un statut, ni lire une
  autre table.

## 4. 🟠 Aucune RLS (le piège classique Supabase)

Brancher `supabase-js` avec la clé `anon` sans politique RLS = base **ouverte en lecture/écriture** à
tout Internet (la clé est publique par design). Le schéma livré :

```sql
alter table public.staff, public.orders, public.payments … enable row level security;
revoke all on all tables in schema public from anon, authenticated;   -- puis on rend au cas par cas
create policy orders_team on public.orders for select to authenticated using (public.is_team());
```

Et les fonctions internes sont retirées du rôle public :

```sql
revoke all on function public.place_order_core(uuid,jsonb,text,text,uuid) from anon, authenticated;
```

(Par défaut, PostgreSQL autorise `PUBLIC` à exécuter toute fonction — oubli très fréquent.)

## 5. 🟠 Table choisissable librement

```html
<!-- AVANT : menu déroulant Table 1 → 20, depuis n'importe où -->
<select onchange="D.client.table=this.value">…</select>
```

**Après** : la table vient du QR (`?t=T07&k=<jeton>`). Le jeton est vérifié dans la fonction
`client_place_order`. Le sélecteur est remplacé par un badge en lecture seule, et surtout
`qr_token` **n'est pas lisible par `anon`** :

```sql
create view public.v_tables_public as select code,label,seats from public.resto_tables where is_active;
-- resto_tables (avec qr_token) : accessible seulement à l'équipe connectée
```

Sans ça, un client pouvait lire les 21 jetons et commander pour n'importe quelle table.

## 6. 🟠 Spam / déni de service

Rien n'empêchait d'envoyer 500 commandes. Trois garde-fous en base :
`check_throttle()` (12 appels/minute/table), limites de volume (40 lignes, 100 articles, `qty ≤ 99`),
et l'index unique partiel `orders_one_open_per_table` (une seule commande ouverte par table).

## 7. 🟠 Paiements

```js
// AVANT : montant libre, aucune vérification, aucune trace de qui encaisse
o.pays.push({amt:a,op});
```

```sql
-- APRÈS : refus si dépassement, sinon enregistrement avec l'auteur et fermeture auto
if p_amount > v_left + 0.01 then raise exception 'Montant supérieur au reste à payer (% MRU)', round(v_left,2); end if;
insert into public.payments (order_id,amount,method,phone,received_by) values (p_order,…, (select auth.uid()));
```

Bonus : la commande est fermée automatiquement quand `payé ≥ total` (trigger `tg_close_when_paid`),
donc la table se libère même si le serveur oublie de cliquer.

## 8. 🟡 XSS stocké

`esc()` était déjà utilisé pour les noms et les notes (bien), mais deux trous :

```js
// URL d'image injectée telle quelle
${m.img?`<img src="${m.img}"…>`
```

Corrigé par un filtre + échappement :

```js
${m.img&&/^(https?:\/\/|data:image\/)/i.test(m.img)?`<img src="${esc(m.img)}"…>`:'🍽️'}
```

La cause racine reste qu'un `localStorage` est modifiable par l'utilisateur ; désormais les contenus
viennent de la base, où seul l'admin peut écrire. Pour finir, ajouter une CSP à l'hébergement
(Cloudflare Pages → `_headers`, Netlify → `_headers`) :

```
/*
  Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://cdn.tailwindcss.com https://cdn.jsdelivr.net https://*.supabase.co; connect-src 'self' https://*.supabase.co wss://*.supabase.co; img-src 'self' data: blob: https://*.supabase.co; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; frame-ancestors 'none'
  X-Frame-Options: DENY
  Referrer-Policy: strict-origin-when-cross-origin
```

## 9. 🟡 Photos

Base64 dans `localStorage` = 5 Mo de quota, plantage « stockage plein » au 4ᵉ plat, et photos perdues
d'un appareil à l'autre. Désormais `menu_items.image_url` + bucket Storage `menu` (public en lecture,
écriture admin, 2 Mo, JPEG/PNG/WebP uniquement), compression 640 px conservée.

## 10. 🟡 Purge de l'historique

Avant : corbeille accessible dans l'en-tête, effacement total irréversible (et sur un seul appareil).
Après : `staff_purge_history()` — **admin uniquement**, et seulement les commandes **soldées**
(`closed_at is not null`). Les commandes en cours ne peuvent pas disparaître.

## 11. 🟡 Sessions

Avant : `un={}` en mémoire, un PIN saisi une fois = accès jusqu'au rechargement, aucune expiration.
Après : JWT Supabase (à régler à 12 h, étape 6 de l'installation), `signOut()` réel sur **Verrouiller**,
et `sb.auth.onAuthStateChange` renvoie vers l'écran client si la session expire ou est révoquée ailleurs.

## 12-13. 🟢 Partage et tickets

Une seule base pour le serveur, la caisse et la cuisine (fini les commandes en double ou perdues) ;
numéro de ticket séquentiel `CC-0042` (`order_no`) au lieu de `C` + 6 chiffres du timestamp.

## 14. 🟢 Dépendances

Tailwind via `cdn.tailwindcss.com` (non recommandé en production), Chart.js et supabase-js via CDN :
- ajouter `integrity="sha384-…"` (SRI) sur les `<script>`, ou
- compiler Tailwind localement et servir un fichier `app.css` — plus rapide et compatible CSP stricte.

---

## Ce qui reste volontairement simple (et à surveiller)

1. **`check_throttle` s'appuie sur l'en-tête IP fourni par l'hébergeur.** Si l'appel ne passe pas par
   Supabase (client PostgREST direct), l'en-tête peut être absent : le compteur retombe alors sur
   `'unknown'` et limite globalement plutôt que par IP. Pour une vraie protection, mettre une
   **Edge Function** devant `client_place_order`.
2. **Le jeton du QR est un secret partagé par table.** Une photo du QR de la table 12 permet de
   commander pour la table 12. C'est acceptable (on le fait bien avec un QR de menu) ; en cas d'abus :
   `update public.resto_tables set qr_token = gen_random_uuid()` + réimpression.
3. **Pas de logs d'audit** au-delà de `received_by` / `created_by`. Si tu veux « qui a supprimé quoi »,
   ajouter une table `audit_log` alimentée par triggers.
4. **Sauvegardes** : plan gratuit = pas de restauration automatique → export CSV hebdomadaire
   (étape 11 de l'installation).

## Ce qui a été vérifié pour toi

- Les 2 scripts SQL ont été exécutés sur un **PostgreSQL 17** réel (schéma + seed + relance = idempotents).
- RLS testée : `anon` → `permission denied` sur `orders`, `order_items`, `resto_tables` ;
  lecture OK sur le menu et sur `v_tables_public`.
- Parcours complet simulé en base : commande client (prix imposé, sous-total 350), changement de statut,
  acompte 200, refus d'un sur-paiement, solde, fermeture automatique, nouvelle tournée sur la même table,
  déplacement de table, refus de déplacement vers une table occupée, purge refusée au serveur.
- Anti-spam : 12 commandes acceptées, la 13ᵉ refusée sur la même minute.
- Application corrigée testée en navigateur simulé (jsdom) : mode démo, mode Supabase (client QR → envoi
  de commande), connexion admin → commandes/cuisine/historique/stats/menu, encaissement, dépense,
  masquage d'un plat. Zéro erreur JavaScript.
- Les 21 QR codes ont été décodés après génération : chacun pointe vers la bonne table et le bon jeton.
