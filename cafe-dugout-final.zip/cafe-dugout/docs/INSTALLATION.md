# Café Dugout — Installation Supabase (pas à pas)

Tout ce qui doit aller dans Supabase, dans quel ordre, et ce qu'il faut copier où.

**Deux versions de l'application, une seule base :**
- la racine → **Next.js 14** (recommandée : URL propres, sécurité serveur, QR imprimables depuis l'app)
- `extras/version-html-simple/index.html` → 1 seul fichier HTML, sans installation (dépannage)

Les deux utilisent exactement le même schéma SQL et les mêmes fonctions sécurisées.

---

## Ce que contient le dossier

| Fichier | À quoi ça sert | Où ça va |
|---|---|---|
| `supabase/1_schema.sql` | Structure : tables, sécurité (RLS), fonctions, storage | **SQL Editor de Supabase** (1 fois) |
| `supabase/2_seed.sql` | Données de départ : 21 tables + 7 produits + catégories | **SQL Editor de Supabase** (1 fois) |
| `supabase/4_security_hardening.sql` | Durcissement sécurité (débit en base, paiements, webhooks, idempotence) | **SQL Editor** (1 fois) |
| `supabase/3_migration_choix_table.sql` | Ajoute « le client choisit sa table » (à lancer **seulement** si tu avais déjà installé le schéma avant cette mise à jour) | **SQL Editor** (1 fois) |
| racine du projet | **L'application Next.js** (version principale : menu QR, POS, cuisine, stats, QR des tables) | Vercel (ou `npm run dev` en local) |
| `extras/version-html-simple/index.html` | Même application en **1 seul fichier HTML** (dépannage, pas de serveur à installer) | N'importe quel hébergement statique |
| `qr/Cafe-Dugout-QR-Tables.pdf` | Planche A4 des 21 QR codes à imprimer | Imprimante |
| `qr/codes/T01.png … EMP.svg` | Chaque QR en fichier séparé (PNG + SVG) | Au choix |
| `qr/planche-qr.html` | La même planche en HTML (impression navigateur) | — |
| `qr/generate_qr.py` | Régénère tous les QR avec ta vraie URL | Sur ton PC (`python3`) |
| `qr/tables.json` | Code table + jeton du QR (le lien entre la base et le papier) | Ne pas modifier à la main |
| `AUDIT_FAILLES.md` | Les failles trouvées et leurs corrections | À lire |
| `screenshots/` | Captures réelles de l'app (client, POS, cuisine, stats, QR, ticket) | Aperçu |
| `mock/supabase-mock.mjs` | Faux Supabase pour tester sans projet réel | Développement local |
| `uploads/app.html` | L'ancienne version (localStorage + codes PIN) | Sauvegarde |

---

## Étape 1 — Créer le projet Supabase

1. https://supabase.com → **New project**
2. Nom : `cafe-dugout` · Région : **Europe (Frankfurt)** ou **West EU** (le plus proche de la Mauritanie)
3. Note le **mot de passe de la base** (garde-le, il ne sert qu'à `psql`)
4. Attends ~2 minutes que le projet soit prêt.

---

## Étape 2 — Coller le schéma (le plus important)

1. Menu de gauche → **SQL Editor** → **New query**
2. Ouvre `supabase/1_schema.sql`, **copie tout**, colle, puis **Run** (ou Ctrl+Entrée)
3. Tu dois voir `Success. No rows returned` (les messages `NOTICE ... does not exist, skipping` sont normaux).
4. **New query** → ouvre `supabase/2_seed.sql`, copie tout, colle, **Run**.
   *(Installation neuve : le schéma contient déjà la fonction « choix de table » — tu n'as pas besoin
   du fichier `3_migration_…`. Si tu avais installé la version précédente, lance-le une fois.)*
5. Vérification — colle ceci et exécute :

```sql
select (select count(*) from public.resto_tables) as nb_tables,
       (select count(*) from public.menu_items)  as nb_produits,
       (select count(*) from public.categories)  as nb_categories;
```

Résultat attendu : **21 · 7 · 4**.

> Les deux scripts sont idempotents : tu peux les relancer sans rien casser (sauf `2_seed.sql` qui remet les prix de départ à jour).

---

## Étape 3 — Créer les comptes du personnel

Il n'y a **plus de code PIN** : chaque employé a un vrai compte.

1. Menu → **Authentication** → **Users** → **Add user** → **Create new user**
2. Email + mot de passe (8 caractères min.) → coche **Auto Confirm User** → **Create user**
3. Répète pour chaque personne (toi, le gérant, les serveurs, la cuisine).

---

## Étape 4 — Donner un rôle à chaque compte

Toujours dans **SQL Editor** — une ligne par personne :

```sql
-- toi (tout : statistiques, menu, dépenses, purge)
select public.promote_staff('patron@cafedugout.mr', 'admin',   'Mohamed');

-- le gérant (commandes, cuisine, historique — pas les stats/menu/dépenses)
select public.promote_staff('gerant@cafedugout.mr',  'gerant',  'Fatimetou');

-- les serveurs (commandes + encaissement)
select public.promote_staff('serveur1@cafedugout.mr','serveur', 'Sidi');
select public.promote_staff('serveur2@cafedugout.mr','serveur', 'Aicha');

-- la cuisine (écran KDS uniquement)
select public.promote_staff('cuisine@cafedugout.mr', 'cuisine', 'Chef');
```

Vérification :

```sql
select s.full_name, s.role, s.is_active, u.email
  from public.staff s join auth.users u on u.id = s.id
 order by s.role;
```

> Sans cette étape, la personne peut se connecter mais **rien ne s'ouvre** : aucun rôle = aucun droit (c'est voulu).

---

## Étape 5 — Récupérer l'URL et la clé, les mettre dans l'app

1. **Project Settings** (roue dentée) → **API**
2. Copie :
   - **Project URL** → `https://xxxxx.supabase.co`
   - **anon / public** (clé `anon`) → le très long `eyJhbGciOi...`
3. **Version Next.js (recommandée)** : à la racine, copie `.env.local.example` en `.env.local` :

```env
NEXT_PUBLIC_SUPABASE_URL=https://xxxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6...
```

puis `npm install` et `npm run dev` (http://localhost:3000).

   **Version 1 fichier HTML** (si tu préfères ne rien installer) : ouvre `extras/version-html-simple/index.html`
   et remplace les 2 lignes du bloc `CFG` en haut du script.

> ⚠️ **Jamais** la clé `service_role` dans l'app ni dans une variable `NEXT_PUBLIC_*`. Elle contourne
> toute la sécurité. La clé `anon` est publique par design : c'est la RLS qui protège.

Sans ces valeurs, l'app affiche un écran « Supabase n'est pas encore configuré » (Next.js) ou un
bandeau **MODE DÉMO** (version HTML) et n'enregistre rien.

---

## Étape 6 — Régler l'authentification (2 minutes, important)

**Authentication** → **Sign In / Providers** → **Email** :

- **Allow new users to sign up** → ❌ **OFF** (seul l'admin crée des comptes)
- **Confirm email** → peut rester OFF (comptes créés par toi)
- **Minimum password length** → 8 (ou 10)

**Authentication** → **Sessions** :

- **Time-box user sessions** → 12 h (ou la durée d'un service)
- **Refresh token** → 7 jours maximum

Comme ça, un téléphone perdu n'a pas un accès éternel.

---

## Étape 7 — Vérifier le storage des photos

Le bucket a été créé par `1_schema.sql`. Contrôle rapide dans **Storage** :

- bucket **menu** existe, marqué **Public**
- limite 2 Mo, types `image/jpeg`, `image/png`, `image/webp`
- **Policies** : lecture publique, écriture réservée à l'admin

Rien à faire de plus.

---

## Étape 8 — Héberger l'application

### Version Next.js (recommandée) — Vercel

1. Pousser tout le dossier sur GitHub.
2. https://vercel.com → **Add New Project** → importer le dépôt (laisser Root Directory vide : le projet est à la racine).
3. **Environment Variables** : `NEXT_PUBLIC_SUPABASE_URL` et `NEXT_PUBLIC_SUPABASE_ANON_KEY`.
4. **Deploy** → URL du type `https://cafe-dugout.vercel.app`.
5. Supabase → **Authentication → URL Configuration** : mettre cette URL en *Site URL* et l'ajouter aux
   *Redirect URLs*.

### Version 1 fichier HTML (dépannage)

**Cloudflare Pages** : Workers & Pages → Create → Pages → Upload assets → glisser
`extras/version-html-simple/` (le fichier doit s'appeler `index.html`) → Deploy.
**Netlify** : https://app.netlify.com/drop → glisser le dossier.

URL de test : `https://ton-site/?t=T07&k=...` (Next.js) ou `https://ton-site/index.html?t=T07&k=...`

---

## Étape 9 — Générer les QR avec TA vraie URL

**Le plus simple avec Next.js** : une fois connecté en admin → onglet **QR des tables** → les 21 QR sont
générés depuis la base avec la bonne URL → bouton **Imprimer la planche**. Rien à installer.

Sinon, en local (les QR livrés pointent vers `https://cafe-dugout.pages.dev`, une URL de démo) :

1. Ouvre `qr/generate_qr.py`, ligne `BASE_URL = "https://cafe-dugout.pages.dev/"` → mets ton URL
2. Sur un PC avec Python :

```bash
python3 -m pip install segno fpdf2
python3 qr/generate_qr.py
```

3. Résultat : `qr/Cafe-Dugout-QR-Tables.pdf` (planche A4) + `qr/codes/*.png` mis à jour.
4. Imprime la planche, découpe, plastifie (ou imprime sur sticker), colle sur chaque table.

**Comment le QR fonctionne** : chaque QR contient
`https://ton-site/?t=T07&k=<jeton unique de la table>`.
Le client scanne → l'app ouvre le menu **déjà rattaché à la Table 7**. C'est `k` qui authentifie la table côté base : impossible de commander pour une autre table, et le jeton n'est jamais visible par les clients.

**Ajouter une table plus tard** (ex. la 21e) :

```sql
insert into public.resto_tables (code, label, seats) values ('T21','Table 21',4)
returning code, qr_token;   -- note le qr_token renvoyé
```

puis génère son QR (ajoute-la dans `qr/tables.json` avec ce `qr_token`, relance le script), ou imprime juste le lien avec n'importe quel générateur de QR : `https://ton-site/?t=T21&k=<qr_token>`.

**Changer le jeton d'une table** (si un QR a fuité) :

```sql
update public.resto_tables set qr_token = gen_random_uuid()
 where code = 'T07' returning qr_token;   -- réimprime le QR de la table 7
```

---

## Étape 9 bis — Sécurité (fortement recommandé avant l'ouverture)

1. **SQL** : *New query* → colle `supabase/4_security_hardening.sql` → **Run**.
   Tu dois voir en bas : `4 | 3 | 1` (4 fonctions, 3 tables, 1 colonne ajoutées).
2. **Variables serveur** (Vercel → *Settings → Environment Variables*, ou `.env.local`) :
   - `SUPABASE_SERVICE_ROLE_KEY` — *Project Settings → API → service_role*.
     ⚠️ **Jamais** dans une variable `NEXT_PUBLIC_*`, jamais dans le navigateur.
   - `TABLE_TOKEN_SECRET` — `openssl rand -base64 48` (QR de session).
   - `PAYMENT_SECRET_BANKILY`, `_MASRIVI`, `_SEDAD`, `_CLICK` — les clés de tes contrats.
3. **Redis (gratuit, 2 min)** : compte sur upstash.com → copie `UPSTASH_REDIS_REST_URL`
   et `UPSTASH_REDIS_REST_TOKEN`. Sans ça, la limite anti-spam est calculée
   séparément par chaque instance Vercel (elle reste active, mais moins stricte).
4. **Supabase → Authentication → Rate Limits** : 10 tentatives / 5 minutes par IP,
   et « Allow new users to sign up » = **OFF**.

Le détail des protections (et ce qu'il reste à vérifier avec les opérateurs de paiement)
est dans **`AUDIT_SECURITE_COMPLET.md`**.

## Étape 10 — Recette (à faire une fois, avant d'ouvrir)

> PWA : sur Android/Chrome, un bouton **Installer** apparaît dans l'en-tête ; sur iPhone, Partager →
> « Sur l'écran d'accueil ». L'app s'ouvre alors en plein écran, sans barre d'adresse.

0. `npm run dev` (ou l'URL Vercel) : la page `/` doit afficher le menu, `/login` le formulaire.
1. Sur ton téléphone : ouvre l'app, le **sélecteur de table** s'ouvre → choisis Table 3, ou scanne le
   QR de la table 3 si tu l'as déjà imprimé (la table est alors pré-remplie).
2. Ajoute 2 plats, **Envoyer la commande** → « Commande envoyée en cuisine ✓ ».
3. Sur un 2e appareil (ou onglet) : icône à gauche → connexion serveur → l'onglet **Commandes** montre la Table 3.
4. **Écran Cuisine** → la commande apparaît ; clique `Attente ›` → `Prêt` ; l'autre appareil se met à jour seul (15 s).
5. **Payer** → Bankily 200 → valider → reste à payer = le solde ; encaisse le reste → la table se libère.
6. **Historique** → le ticket s'imprime (bouton imprimante).
7. Connexion admin → **Menu & Produits** : modifie un prix, ajoute un plat avec photo → rafraîchis le téléphone client : c'est à jour.
8. Vérifie qu'un serveur **ne voit pas** Statistiques / Menu (cadenas sur les onglets).

---

## Étape 11 — Sauvegardes (à ne pas sauter)

Le plan gratuit n'a pas de sauvegarde automatique.

- **Hebdo** : Supabase → **Database** → **Backups** si dispo, sinon **SQL Editor** :

```sql
-- export rapide des commandes des 30 derniers jours
select * from public.v_orders_full
 where opened_at > now() - interval '30 days'
 order by opened_at desc;
```
→ bouton **Download CSV** en bas du tableau.

- Ou, depuis un PC : `pg_dump` avec la chaîne de connexion (Project Settings → Database → Connection string).

---

## Rappels de sécurité (après installation)

| Règle | Pourquoi |
|---|---|
| Ne jamais publier la clé `service_role` | elle ignore toute la sécurité |
| `Allow new users to sign up` = OFF | sinon n'importe qui crée un compte |
| Un compte = une personne, mot de passe fort | la traçabilité des encaissements en dépend |
| Retirer un employé : `Authentication > Users > Delete` | coupe l'accès immédiatement |
| Ne pas partager le PDF des QR publiquement | le jeton permet de commander depuis la table |
| Sauvegarde CSV chaque semaine | plan gratuit = pas de restauration auto |

---

## En cas de problème

| Symptôme | Cause probable | Solution |
|---|---|---|
| Écran « Supabase n'est pas encore configuré » / bandeau **MODE DÉMO** | URL ou clé non remplies | étape 5 |
| « Connexion refusée : Invalid login credentials » | email/mot de passe, ou compte non confirmé | Authentication → Users → éditer |
| « Compte sans rôle actif » après connexion | aucun rôle en base | étape 4 (`promote_staff`) |
| « QR invalide » | jeton absent de la base (seed non lancé, ou table supprimée) | relance `2_seed.sql`, vérifie avec `select code, qr_token from public.resto_tables;` |
| « permission denied for table … » | le SQL de sécurité n'a pas été lancé en entier | relance `1_schema.sql` |
| « Trop de commandes envoyées » | protection anti-spam (12 / minute / table) | normal, attendre 1 minute |
| Photos qui ne s'affichent pas | bucket `menu` non public / policies manquantes | relance la section 9 de `1_schema.sql` |

## Étape ajoutée — inventaire du magasin
Exécuter `supabase/6_inventory.sql`. Ensuite : espace équipe (admin ou gérant) > onglet **Inventaire** : Stock, ↓ Entrée (réception fournisseur), ↑ Sortie vers resto (cuisine, bar, salle), Historique. Le stock est la somme des mouvements ; une sortie au-delà du stock disponible est refusée.

## Étape ajoutée — icônes des rubriques
Exécuter aussi `supabase/5_category_icons.sql` (colonne `categories.icon_url`). Ensuite : espace équipe > Menu & Produits > « Icônes des rubriques » > Changer (PNG, JPG ou WebP). Les photos des plats se changent dans le même onglet.
