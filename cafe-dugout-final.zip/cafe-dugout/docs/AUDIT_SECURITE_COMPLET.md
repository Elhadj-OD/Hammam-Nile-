# Audit de sécurité & durcissement — Café Dugout / Resto-OS

> **Périmètre réel audité** : l'application livrée dans `cafe-dugout-next-pwa.zip`
> (Next.js 14 App Router + Supabase/PostgreSQL + PWA).
> Le document couvre les 5 axes demandés et fournit le **code effectivement écrit,
> compilé et testé** dans le projet — pas seulement des recommandations.
>
> **Statut des tests** : 24 tests d'API (`security-test.mjs`) + 11 tests navigateur
> (`rbac-test.mjs`) + 6 vérifications SQL (`psql`) → **tous verts**.
> Détail des résultats en annexe A.
>
> Date : 5 novembre 2026 · Base cible : Supabase (PostgreSQL 15) · Hébergement : Vercel

---

## Sommaire

1. [Analyse complète des failles et manquements](#1-analyse-complète-des-failles-et-manquements)
2. [Modèle de validation des données (schemas / middlewares)](#2-modèle-de-validation-des-données)
3. [Contrôle d'accès (RBAC & vérification JWT)](#3-contrôle-daccès-rbac--vérification-jwt)
4. [Vérification sécurisée des webhooks de paiement](#4-module-backend-de-vérification-sécurisée-des-webhooks)
5. [Sécurisation des jetons QR de table](#5-système-de-sécurisation-des-jetons-qr-de-table)
6. [Stratégie de repli réseau et gestion hors-ligne](#6-stratégie-de-fallback-réseau-et-gestion-hors-ligne)
7. [Ce qu'il reste à faire côté exploitation](#7-ce-quil-reste-à-faire-côté-exploitation)
8. [Annexes (A : résultats des tests · B : variables d'env · C : équivalents FastAPI)](#annexe-a--résultats-des-tests-exécutés)

---

## 1. Analyse complète des failles et manquements

### 1.1 Méthode

Trois angles complémentaires, parce qu'une application peut être sûre « côté serveur »
et trouée côté navigateur (et inversement) :

| Angle | Question posée | Outils |
|---|---|---|
| **Modèle de menace** | Qui attaque ? Un client malin, un employé indélicat, un bot, un faux webhook ? | Revue des flux + scénarios d'abus |
| **Revue de code** | Où sont les points d'entrée non validés ? | Lecture des routes, composants, SQL |
| **Test réel** | Est-ce que l'attaque marche ? | Scripts Playwright + `curl` + `psql` |

Les acteurs considérés :

- **Client anonyme** : possède la clé `anon` (publique, c'est normal) et peut appeler Supabase en direct sans passer par l'app.
- **Employé** : compte valide, rôle `serveur` ou `cuisine` → ne doit pas atteindre l'administration.
- **Attaquant externe** : force la connexion, spamme les commandes, rejoue des webhooks, forge des URL de table.
- **Intercepteur réseau** : voit passer les requêtes (wifi public, téléphone compromis).

### 1.2 Tableau des failles — état avant / après

Légende gravité : 🔴 critique · 🟠 élevée · 🟡 moyenne

| # | Faille / manquement | Gravé | Avant | Correction (fichier) |
|---|---|---|---|---|
| 1 | Aucune limite de débit sur la création de commandes → spam, saturation cuisine | 🟠 | ❌ | `lib/security/rate-limit.js` + `app/api/orders/route.js` + `check_rate_limit()` en SQL |
| 2 | Pas de limite sur les tentatives de connexion → brute force | 🔴 | ⚠️ (GoTrue seul) | §1.4 + §7 : limites Supabase Auth + `check_rate_limit` côté base |
| 3 | Entrées non validées (prix, quantités, codes de table) | 🔴 | ⚠️ partiel (SQL) | `lib/security/schemas.js` (Zod `.strict()`) |
| 4 | Un client pouvait viser `/api/stats` ou l'admin sans contrôle applicatif | 🔴 | ❌ | `lib/security/rbac.js` + `guardApi()` + `app/api/stats/route.js` |
| 5 | Onglets d'administration **affichés** (mais désactivés) à un serveur | 🟡 | ❌ | `components/pos/PosApp.js` → `TABS.filter(can(role, level))` |
| 6 | Aucun webhook de paiement : impossible de vérifier une notification d'opérateur | 🔴 | ❌ | `app/api/payments/webhook/[provider]/route.js` + `lib/security/signature.js` |
| 7 | Clés secrètes opérateurs absentes du modèle de configuration | 🔴 | ❌ | `.env.local.example` (sans préfixe `NEXT_PUBLIC_`) + `lib/security/env-check.js` |
| 8 | Pas d'idempotence : un rejeu de webhook créditait deux fois | 🔴 | ❌ | `webhook_events (provider, event_id) UNIQUE` + `webhook_apply_payment()` |
| 9 | QR de table = code en clair (`?t=T05`) → usurpation triviale de table | 🟠 | ⚠️ | `lib/security/qr.js` (HMAC signé, TTL 15 min) + `/api/table/session` |
| 10 | Le jeton QR permanent circulait dans l'URL et l'historique du navigateur | 🟡 | ⚠️ | QR de session signé, rotation possible, jeton permanent limité à l'usage serveur |
| 11 | Aucune protection hors-ligne : commande perdue si le réseau coupe | 🟡 | ❌ | `lib/offline/outbox.js` (IndexedDB + `client_ref` idempotent) |
| 12 | **Bug réel trouvé pendant les tests** : `ReferenceError: sessionToken is not defined` → l'écran client ne parvenait plus à préremplir la table | 🟠 | ❌ (introduit puis détecté) | `components/client/ClientMenu.js` (signature du composant) |
| 13 | Erreurs SQL/exceptions renvoyées brutes au navigateur | 🟡 | ⚠️ | `lib/security/http.js` : `guarded()`, messages courts, 500 génériques |
| 14 | Absence d'anti-CSRF sur les routes mutantes | 🟠 | ❌ | `sameOrigin()` dans `/api/orders` (contrôle de l'en-tête `Origin`) |
| 15 | `service_role` jamais nécessaire… donc jamais chargée, donc webhooks impossibles | 🟡 | — | `lib/supabase/admin.js` avec garde `typeof window !== 'undefined'` |
| 16 | Payload volumineux accepté (DoS mémoire) | 🟡 | ❌ | `middleware.js` : refus au-delà de 100 Ko (`413`) |
| 17 | Politique de sécurité du contenu (CSP) incomplète pour les appels navigateur | 🟡 | ⚠️ | `next.config.mjs` : `connect-src 'self' <supabase>`, `frame-ancestors 'none'` |

### 1.3 Failles déjà corrigées lors de l'audit précédent (rappel)

Conservées ici pour la traçabilité — détail dans `AUDIT_FAILLES.md` :

- prix **relus en base** (`menu_items`) au moment de la commande ; le navigateur ne peut pas payer moins cher ;
- sur-paiement refusé (`staff_record_payment`) ;
- jetons QR **opaques** (UUID), lisibles uniquement par l'équipe, jamais listés à `anon` ;
- **RLS active partout** ; le rôle vient de `public.staff(role)`, jamais d'un cookie ou du navigateur ;
- bucket Storage limité à 2 Mo, types MIME filtrés ;
- `service_role` absent de l'application.

### 1.4 Points de vigilance qui ne se corrigent pas dans le code

Trois réglages se font dans les consoles (détaillés au §7) :

1. **Supabase Auth** → `Authentication > Rate Limits` : la connexion se fait **directement
   entre le navigateur et Supabase**. Aucun middleware applicatif ne voit ces requêtes :
   la limite doit être posée dans Supabase (valeur conseillée : 10 tentatives / 5 min / IP).
2. **Rotation des secrets** → changer `TABLE_TOKEN_SECRET` invalide instantanément tous les
   QR de session en circulation (les QR papier restent valables, voir §5.4).
3. **Sauvegardes** → la sécurité ne remplace pas une restauration testée (`pg_dump` quotidien).

### 1.5 Ce qui n'est **pas** couvert (assumé, à décider)

- **2FA pour l'admin** : Supabase le supporte (MFA TOTP), non activé ici → recommandé avant
  la mise en production réelle.
- **WAF / anti-DDoS** : Vercel absorbe une partie, mais rien ne remplace Cloudflare si l'app
  devient populaire. Le rate limiting applicatif est le premier rempart, pas le dernier.
- **Chiffrement au repos des numéros de téléphone** : `payments.phone` est en clair. RGPD/loi
  2017-020 (Mauritanie) : à décider avec le juriste du restaurant.
- **Signatures des opérateurs** : le schéma exact est **contractuel**. Le code implémente un
  HMAC-SHA256 standard et un cas Click (MD5) — **à confirmer opérateur par opérateur** (§4.5).

---

## 2. Modèle de validation des données

### 2.1 Principe : zéro confiance dans le navigateur

Trois règles, appliquées sans exception :

1. **Tout ce qui vient du client est une chaîne hostile** — même si l'interface l'a produit.
2. **Les champs interdits n'existent pas** : le schéma est `.strict()`, donc un `price`
   injecté provoque un `400`, il n'est pas « ignoré ».
3. **La validation applicative ne remplace jamais la validation base** : le serveur revérifie
   tout (prix, disponibilité, totaux) dans une fonction SQL `security definer`.

### 2.2 Schémas Zod — `next-app/lib/security/schemas.js`

```js
import { z } from 'zod'

/** Codes de table acceptés : T01 … T20 + EMP (à emporter). */
export const tableCode = z.string().trim().toUpperCase()
  .regex(/^(T(0[1-9]|1[0-9]|20)|EMP)$/, 'Code table invalide')

/** Un item : identifiant produit + quantité + note. Rien d'autre. */
export const orderItem = z.object({
  menu_item_id: z.string().uuid('Identifiant produit invalide'),
  qty: z.number().int().min(1, 'Quantité minimum 1').max(20, 'Quantité maximum 20'),
  note: z.string().trim().max(140, 'Note trop longue (140 caractères)').nullish()
}).strict()          // ← rejette { price: 1 } ou { unit_price: 0.01 }

export const orderSchema = z.object({
  table: tableCode.optional(),
  qr_token: z.string().trim().min(8).max(64).optional(),
  items: z.array(orderItem).min(1, 'Panier vide').max(30, 'Trop d’articles'),
  note: z.string().trim().max(200).nullish(),
  client_ref: z.string().uuid('Référence client invalide')   // idempotence
}).strict()
  .refine(v => Boolean(v.table) !== Boolean(v.qr_token), {
    message: 'Fournir soit une table, soit un jeton QR'
  })
```

Résultat mesuré (test A) :

```
✅ prix injecté par le client (price: 1) rejeté   → items.0 : Unrecognized key(s) in object: 'price'
✅ quantité 0 rejetée                             → items.0.qty : Quantité minimum 1
✅ quantité 500 rejetée                           → items.0.qty : Quantité maximum 20
✅ table + jeton QR en même temps rejeté          → Fournir soit une table, soit un jeton QR
✅ code de table inventé (Z99) rejeté             → table : Code table invalide
✅ panier de 31 lignes rejeté                     → items : Trop d’articles
```

### 2.3 Middleware — `next-app/middleware.js`

Le middleware fait trois choses **avant** que la requête n'atteigne une route :

```js
if (pathname.startsWith('/api/')) {
  // 1. plafond global : 300 requêtes/minute/IP (anti-scraping, anti-boucle)
  const rl = await rateLimit({ key: `api:${ip}`, limit: 300, windowMs: 60_000 })
  if (!rl.ok) return new NextResponse(JSON.stringify({ error: 'rate_limited' }),
    { status: 429, headers: { 'retry-after': String(rl.retryAfter) } })

  // 2. corps anormalement gros : refusé avant lecture (DoS mémoire)
  if (Number(request.headers.get('content-length') || 0) > 100_000) { /* 413 */ }
}
// 3. rafraîchissement de la session Supabase (cookies httpOnly)
```

### 2.4 Limitation de débit — `next-app/lib/security/rate-limit.js`

Une seule API, deux moteurs :

| Contexte | Moteur | Pourquoi |
|---|---|---|
| Développement, mono-instance | `Map` en mémoire | zéro dépendance, zéro coût |
| **Production Vercel (obligatoire)** | Redis via Upstash REST | chaque lambda a sa mémoire : sans Redis, la limite est multipliée par le nombre d'instances |

```js
export async function rateLimit({ key, limit = 30, windowMs = 60_000 }) {
  if (useRedis) {
    try { return await redisLimit(key, limit, windowMs) }
    catch { return memoryLimit(key, limit, windowMs) }   // Redis HS → on ne bloque pas le service
  }
  return memoryLimit(key, limit, windowMs)
}
```

Les limites posées, par endpoint :

| Route | Limite | Clé | Justification |
|---|---|---|---|
| `/api/*` (global) | 300 / min | IP | scraping, boucle de client défaillant |
| `POST /api/orders` | 20 / min | IP | un client normal commande 1 à 3 fois |
| `POST /api/orders` | 10 / min | **table** | empêche une table de noyer la cuisine |
| `client_place_order_secure()` SQL | 10 / min | code table | **second rideau** : protège même si l'API est contournée |
| `GET /api/table/session` | 60 / min | IP | évite le brute force de jetons |
| `POST /api/payments/webhook/*` | 120 / min | IP + opérateur | les opérateurs renvoient en rafale après incident |

Résultat mesuré (test D) :

```
✅ 26 commandes d'affilée → 10 acceptées puis blocage   → 16 réponses 429
✅ blocage confirmé après la rafale                     → retry-after = 58s
```

Le client reçoit un `429` avec `Retry-After`, et l'interface affiche
« Trop de commandes, patientez une minute. » au lieu d'une erreur technique.

---

## 3. Contrôle d'accès (RBAC & vérification JWT)

### 3.1 Modèle de rôles

| Rôle | Où il est défini | Ce qu'il peut faire |
|---|---|---|
| `client` | implicite (aucune session) | voir le menu, créer une commande |
| `cuisine` | `public.staff.role` | voir commandes, changer le statut (préparé/prêt) |
| `serveur` | `public.staff.role` | + encaisser, déplacer, annuler |
| `gerant` | `public.staff.role` | + rembourser, purger l'historique |
| `admin` | `public.staff.role` | tout : statistiques, menu, QR, staff |

**Le rôle n'est jamais transmis par le navigateur.** Il est lu en base à chaque requête
(`select role from public.staff where id = auth.uid() and is_active`).

### 3.2 Matrice des permissions — `next-app/lib/security/rbac.js`

Une seule source de vérité, testable :

```js
export const PERMISSIONS = {
  'orders:read':         ['admin', 'gerant', 'serveur', 'cuisine'],
  'orders:create':       ['admin', 'gerant', 'serveur'],
  'orders:update_status':['admin', 'gerant', 'serveur', 'cuisine'],
  'payment:create':      ['admin', 'gerant', 'serveur'],
  'payment:refund':      ['admin', 'gerant'],
  'stats:read':          ['admin'],
  'menu:write':          ['admin'],
  'qr:read':             ['admin'],
  'staff:write':         ['admin']
}

export function can(role, permission) {          // deny by default
  const allowed = PERMISSIONS[permission]
  return Array.isArray(allowed) ? allowed.includes(role) : false
}
```

### 3.3 Trois points d'application (défense en profondeur)

**a) Route API** — `guardApi(permission)` renvoie `401` (pas de session) ou `403` (rôle insuffisant) :

```js
// app/api/stats/route.js
export async function GET() {
  const denied = await guardApi('stats:read')   // ← 401 / 403 déjà formatés
  if (denied) return denied
  const sb = supabaseServer()                   // requête avec la session de l'utilisateur
  ...
}
```

**b) Interface** — on ne rend **que** ce que le rôle autorise (`components/pos/PosApp.js`) :

```js
{TABS.filter(t => can(staff?.role, t.level)).map(t => (
  <button key={t.key} onClick={() => setTab(t.key)}>…</button>
))}
```

> Correction d'audit : auparavant les onglets admin étaient affichés mais `disabled`
> (cadenas). Un serveur voyait donc la surface d'administration. Désormais ils sont absents.

**c) Base de données** — la seule barrière qui compte vraiment. Chaque fonction d'écriture
vérifie le rôle *dans* la fonction (`security definer` + RLS) :

```sql
select role into v_role from public.staff where id = auth.uid() and is_active;
if v_role is null or v_role not in ('admin','gerant','serveur') then
  raise exception 'Non autorisé' using errcode = '42501';
end if;
```

Même avec un `curl` direct sur Supabase muni de la clé `anon`, un client ne peut ni
lire les commandes d'autrui (RLS), ni appeler `webhook_apply_payment` (droit révoqué).

### 3.4 Vérification du JWT : qui le fait ?

| Couche | Vérification | Code |
|---|---|---|
| Navigateur | aucune valeur accordée au jeton ; tout est revalidé | — |
| Next (serveur) | `supabase.auth.getUser()` à chaque requête (appel réseau, **pas** simple décodage) | `lib/supabase/server.js` |
| Middleware | rafraîchit la session expirée, renvoie les cookies | `middleware.js` |
| PostgreSQL | `auth.uid()` + contrôle de `public.staff` | `1_schema.sql`, `4_security_hardening.sql` |

> Point important : `getUser()` (et non `getSession()`) côté serveur, car `getSession()`
> lit le cookie **sans** vérifier la signature auprès de Supabase. Un cookie forgé passerait
> un `getSession()` mais jamais un `getUser()`.

### 3.5 Résultats mesurés (test RBAC, navigateur réel)

```
✅ anonyme /api/stats → 401
✅ /pos sans session → redirigé vers /login
✅ serveur /api/stats → 403 (pas admin)
✅ serveur : onglets admin (Statistiques / QR) non affichés
✅ serveur : onglet Commandes visible
✅ admin /api/stats → 200  → {"orders":6,"revenue":340,"due":1620}
✅ admin : onglet Statistiques visible
```

---

## 4. Module backend de vérification sécurisée des webhooks

### 4.1 Le risque, en une phrase

Un endpoint de webhook **non vérifié** est un bouton « commande payée » offert à Internet :
n'importe qui peut appeler l'URL et créditer une commande, ou en créer des milliers.

### 4.2 Chaîne de traitement — `app/api/payments/webhook/[provider]/route.js`

```
POST /api/payments/webhook/bankily
   │
   ├─ 1. rate limit (120/min par IP + opérateur)
   ├─ 2. opérateur connu ?                        → 404 sinon
   ├─ 3. corps BRUT conservé (req.text())         ← indispensable : re-sérialiser casse la signature
   ├─ 4. signature recalculée + comparaison en TEMPS CONSTANT
   │       + fenêtre temporelle 5 min (anti-rejeu) → 401 sinon
   ├─ 5. validation Zod (montant, référence, statut) → 400 sinon
   ├─ 6. insertion `webhook_events (provider, event_id) UNIQUE`
   │       événement déjà vu ? → 200 {duplicate:true} sans re-créditer
   └─ 7. webhook_apply_payment() (service_role)
           ├─ intent introuvable        → {result:'no_intent'}
           ├─ montant ≠ intent          → {result:'amount_mismatch'} (aucun crédit)
           ├─ reste à payer nul         → {result:'nothing_left'}
           └─ sinon : insert payments + intent.status='paid'
```

### 4.3 Vérification cryptographique — `next-app/lib/security/signature.js`

```js
import crypto from 'node:crypto'

export const PROVIDERS = {
  bankily: { header: 'x-bankily-signature', algo: 'sha256', encoding: 'hex',
             timestampHeader: 'x-bankily-timestamp', toleranceSec: 300,
             build: (ts, raw) => `${ts}.${raw}` },
  // masrivi, sedad : idem (encodage base64 pour sedad)
  click:   { header: 'x-click-signature', algo: 'md5', encoding: 'hex',
             timestampHeader: null, toleranceSec: 0, build: null }  // chaîne Click dédiée
}

export function verifyWebhook({ provider, secret, rawBody, headers, payload, nowSec }) {
  const cfg = PROVIDERS[provider]
  if (!cfg) return { ok: false, reason: 'provider_inconnu' }
  if (!secret || secret.length < 16) return { ok: false, reason: 'secret_absent' }

  // anti-rejeu : un webhook vieux de plus de 5 minutes est refusé
  if (cfg.timestampHeader) {
    const ts = Number(headers.get(cfg.timestampHeader) || 0)
    if (!ts) return { ok: false, reason: 'timestamp_absent' }
    if (Math.abs(nowSec - ts) > cfg.toleranceSec) return { ok: false, reason: 'timestamp_expire' }
  }

  const given = headers.get(cfg.header) || ''
  if (!given) return { ok: false, reason: 'signature_absente' }

  const expected = computeSignature({ provider, secret, rawBody, timestamp, payload })
  return safeEqual(given.toLowerCase(), String(expected).toLowerCase())
    ? { ok: true }
    : { ok: false, reason: 'signature_invalide' }
}

/** Comparaison à temps constant : évite de fuiter la signature octet par octet. */
function safeEqual(a, b) {
  const ba = Buffer.from(String(a)), bb = Buffer.from(String(b))
  if (ba.length !== bb.length) { crypto.timingSafeEqual(ba, ba); return false }
  return crypto.timingSafeEqual(ba, bb)
}
```

Trois détails qui font la différence entre « ça a l'air sûr » et « c'est sûr » :

1. **Corps brut** (`await req.text()`), jamais `JSON.stringify(JSON.parse(body))` :
   l'ordre des clés et les espaces changent la signature.
2. **`timingSafeEqual`** et non `===` : une comparaison naïve permet de deviner la
   signature caractère par caractère en mesurant le temps de réponse.
3. **Fenêtre temporelle** : sans elle, un webhook capturé reste valable éternellement
   (attaque par rejeu), même parfaitement signé.

### 4.4 Idempotence et application en base — `supabase/4_security_hardening.sql`

```sql
create table public.webhook_events (
  id bigserial primary key,
  provider text not null, event_id text not null,
  reference text, amount numeric(10,2), status text,
  payload jsonb not null, received_at timestamptz not null default now(),
  constraint webhook_events_uniq unique (provider, event_id)   -- ← anti-rejeu
);
alter table public.webhook_events enable row level security;   -- aucune policy = service_role seul

create or replace function public.webhook_apply_payment(
  p_provider text, p_event_id text, p_reference text,
  p_amount numeric, p_status text, p_payload jsonb
) returns jsonb language plpgsql security definer as $$
begin
  insert into public.webhook_events (...) values (...)
    on conflict (provider, event_id) do nothing;
  if not found then
    return jsonb_build_object('duplicate', true, 'result', 'already_processed');
  end if;
  -- ... intent, contrôle de montant, plafonnement au reste à payer, insert payments
end $$;

revoke all on function public.webhook_apply_payment(text,text,text,numeric,text,jsonb)
  from public, anon, authenticated;           -- ← le client ne peut PAS appeler cette fonction
grant execute on function public.webhook_apply_payment(...) to service_role;
```

### 4.5 Secrets : isolation totale

| Règle | Application |
|---|---|
| Jamais dans le code | `.env.local.example` ne contient que des noms vides |
| Jamais dans le bundle navigateur | aucun préfixe `NEXT_PUBLIC_` ; vérifié par `lib/security/env-check.js` |
| Un secret par opérateur | une fuite Bankily ne compromet pas Click |
| Côté serveur uniquement | Vercel → *Environment Variables* → portée **Server** |
| Rotation possible | changer la variable suffit, aucun redéploiement de code |

⚠️ **À confirmer avant la production** : la chaîne exacte signée par chaque opérateur
(Bankily, Masrivi, Sedad, Click) est définie dans le **contrat marchand**. Le code
implémente HMAC-SHA256 (défaut) et MD5 pour Click ; si un opérateur signe une autre
chaîne (ex. `amount|reference|secret`), il suffit de modifier son entrée dans
`PROVIDERS` — le reste de la chaîne de vérification ne bouge pas.

### 4.6 Résultats mesurés (test B)

```
✅ sans signature → refusé
✅ signature inventée → refusé
✅ signature calculée avec une autre clé → refusé
✅ signature valide mais vieille d'une heure (rejeu) → refusé
✅ montant modifié après signature → refusé        ← intégrité du corps
✅ signature valide → accepté                        → résultat = no_intent
✅ même événement rejoué → traité une seule fois   → duplicate: true
✅ opérateur inconnu → 404
```

Et côté base (vérifications `psql`) :

```
anon → ERROR: permission denied for function webhook_apply_payment
service_role, montant 10 au lieu de 500 → "amount_mismatch"
service_role, référence inconnue        → "no_intent"
service_role, bon événement             → {"result":"paid","amount":500.00}
service_role, même event_id rejoué      → duplicate = true
puis : 1 paiement(s), 500.00 MRU        ← aucun double crédit
```

---

## 5. Système de sécurisation des jetons QR de table

### 5.1 Le problème

Un QR imprimé contient une URL. Si cette URL contient `?t=T05`, n'importe qui peut :

- changer `T05` en `T07` et **commander sur la table d'un autre** ;
- générer des milliers de commandes sur toutes les tables ;
- photographier un QR et commander depuis chez lui.

### 5.2 Deux niveaux, deux usages

| Niveau | URL | Durée | Usage |
|---|---|---|---|
| **A. QR papier** | `/?t=T05&k=<qr_token>` | permanente (jusqu'à rotation) | collé sur la table ; `qr_token` = UUID secret opaque stocké en base |
| **B. QR de session** | `/?s=v1.<payload>.<hmac>` | 15 min | écran/ardoise à la table, ticket, lien WhatsApp |

Dans les deux cas : **le code de table seul (`?t=T05`) ne suffit plus** à commander via
`/api/orders` → il faut le jeton (mode A) ou le code + validation serveur, et le débit
par table est vérifié en base.

### 5.3 Jeton signé — `next-app/lib/security/qr.js`

```js
const payload = { c: 'T07', e: nowSec + 900, n: nonce }        // table, expiration, aléa
const p = base64url(JSON.stringify(payload))
const token = `v1.${p}.${hmacSha256(payloadB64).slice(0, 32)}`  // TABLE_TOKEN_SECRET
```

Vérification (`/api/table/session`) :

```js
if (parts[0] !== 'v1' || parts.length !== 3) return { ok: false, reason: 'format' }
if (!timingSafeEqual(sig, expected))          return { ok: false, reason: 'signature' }
if (payload.e * 1000 < Date.now())            return { ok: false, reason: 'expire' }
return { ok: true, code: payload.c, exp: payload.e }
```

Conséquences :

- **modifier la table dans le jeton** casse la signature → refusé ;
- **fabriquer un jeton** exige le secret, qui ne quitte jamais le serveur ;
- **un jeton fuité** (capture d'écran, historique) est inutile après 15 minutes.

### 5.4 Rotation et révocation

```sql
-- Rotation des jetons QR permanents (à faire après un départ d'employé ou une fuite)
update public.resto_tables set qr_token = gen_random_uuid();
-- → réimprimer la planche PDF (qr/generate_qr.py)
```

Changer `TABLE_TOKEN_SECRET` invalide **immédiatement** tous les jetons de session en
circulation, sans toucher aux QR papier.

### 5.5 Résultats mesurés (test C)

```
✅ jeton forgé → refusé
✅ jeton valide → table reconnue            → table = T07
✅ jeton expiré → refusé                    → reason = expire
✅ table modifiée dans le jeton → signature invalide
```

---

## 6. Stratégie de fallback réseau et gestion hors-ligne

### 6.1 Contrainte terrain

À Nouakchott, la 4G sature le vendredi soir et saute quand le restaurant est plein.
Une commande qui échoue à l'envoi est une commande perdue **et** un client mécontent.

### 6.2 Principe : « écrire d'abord, envoyer ensuite »

```
[Valider] → écriture IndexedDB (immédiate, locale) → tentative d'envoi
                                                            │
                              ┌─────────────────────────────┴──────────────┐
                         succès                                             échec réseau
                              │                                              │
                     entrée supprimée                        entrée conservée + backoff
                     (2s, 4s, 8s … 60s), renvoi à chaque `online`
```

### 6.3 Pourquoi IndexedDB et pas LocalStorage

| Critère | IndexedDB (retenu) | LocalStorage |
|---|---|---|
| Taille | dizaines de Mo | ~5 Mo, partagés avec l'UI |
| Écriture | asynchrone, ne bloque pas l'écran | synchrone, bloque le thread |
| Structure | objets indexés (`next_at`) | chaînes à parser |
| Verdict | ✅ | écarté |

Le `localStorage` reste utilisé **uniquement** pour un choix d'UI (`cc_table` : dernière
table du téléphone), pas pour des données métier.

### 6.4 Code — `next-app/lib/offline/outbox.js`

```js
export async function enqueue(entry)              // { client_ref, table|qr_token, items, note }
export async function flush(send, { force })      // envoie ce qui est dû, backoff par entrée
export function startAutoSync(send, onResult)     // écoute `online` + filet toutes les 30 s
export function newClientRef()                    // UUID v4 (repli si crypto absent)
```

Boucle d'envoi :

```js
for (const row of rows) {
  try {
    const res = await send(row)
    if (res.ok || res.status === 400 || res.status === 409) {
      await remove(row.client_ref)      // 400 = refusée par la validation → inutile d'insister
      sent++
    } else { failed++; await markFailed(row.client_ref, row.tries + 1) }
  } catch { failed++; await markFailed(row.client_ref, row.tries + 1) }
}
```

### 6.5 Le point critique : idempotence

Sans elle, un renvoi après coupure **crée un doublon** (le client a payé une fois, la
cuisine prépare deux plats). Deux verrous :

1. `client_ref` (UUID généré par le téléphone) ;
2. index unique en base :

```sql
alter table public.orders add column if not exists client_ref uuid;
create unique index orders_client_ref_uniq on public.orders (client_ref)
  where client_ref is not null;
```

et en tête de `client_place_order_secure()` :

```sql
if p_client_ref is not null then
  select o.id into v_existing from public.orders o where o.client_ref = p_client_ref;
  if v_existing is not null then
    return jsonb_build_object('order_id', v_existing, ..., 'duplicate', true);
  end if;
end if;
```

### 6.6 PWA : la coque survit à la coupure

Le service worker (`public/sw.js`, `cafe-dugout-v2`) sert l'application depuis le cache
et une page `offline.html` si la navigation échoue. Le client voit toujours le menu déjà
chargé et un bandeau « Hors ligne » ; la commande part ensuite toute seule.

### 6.7 Résultats mesurés (navigateur réel)

```
✅ coupure réseau : message clair au client
✅ commande écrite dans IndexedDB (file d'attente)   → 1 entrée, client_ref=2a02a887…
✅ retour du réseau : file vidée automatiquement     → 0 entrée restante
```

---

## 7. Ce qu'il reste à faire côté exploitation

Checklist de mise en production (ordre conseillé) :

- [ ] Exécuter `supabase/4_security_hardening.sql` dans le SQL Editor (attendu : `4 | 3 | 1`).
- [ ] Renseigner les variables serveur (voir annexe B) — dont `SUPABASE_SERVICE_ROLE_KEY`,
      `TABLE_TOKEN_SECRET`, `PAYMENT_SECRET_*`.
- [ ] Créer un compte Upstash (gratuit) et renseigner `UPSTASH_REDIS_REST_URL` / `_TOKEN`.
- [ ] Supabase → *Authentication > Rate Limits* : 10 tentatives / 5 min, inscription fermée.
- [ ] Vérifier que la clé `service_role` n'est **pas** dans une variable `NEXT_PUBLIC_*`.
- [ ] Confirmer auprès de chaque opérateur la chaîne exacte signée (§4.5).
- [ ] Activer la MFA sur les comptes admin (recommandé).
- [ ] Planifier `select public.purge_rate_limits();` une fois par jour.
- [ ] Tester une restauration de sauvegarde (sinon les sauvegardes n'existent pas).

Les deux scripts de test livrés servent de **non-régression** : à relancer après toute
modification (`node security-test.mjs`, `node rbac-test.mjs`).

---

## Annexe A — Résultats des tests exécutés

Environnement : build de production (`next build && next start`), base de démonstration
locale (mock Supabase) et PostgreSQL 15 pour la couche SQL.

| Suite | Fichier | Résultat |
|---|---|---|
| Validation, webhooks, jetons, débit | `security-test.mjs` | **24 / 24** |
| RBAC, interface, hors-ligne | `rbac-test.mjs` | **11 / 11** |
| Migration + fonctions SQL | `psql` (4 scripts) | **6 / 6** |

Détail exhaustif :

```
A. Validation des entrées .................... 10 / 10
B. Webhooks de paiement ......................  7 / 7
C. Jetons de table signés ....................  5 / 5
D. Limitation de débit .......................  2 / 2
RBAC navigateur ..............................  7 / 7
File d'attente hors-ligne ....................  4 / 4
SQL (droits, montants, idempotence) ..........  6 / 6
```

Le bug n° 12 du tableau (§1) a été **trouvé par ces tests** puis corrigé : il illustre
pourquoi un audit sans exécution ne suffit pas.

---

## Annexe B — Variables d'environnement

```ini
# Public (visible dans le navigateur)
NEXT_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=eyJhbGci...

# Serveur uniquement — NE JAMAIS préfixer par NEXT_PUBLIC_
SUPABASE_SERVICE_ROLE_KEY=eyJhbGci...          # webhooks (écriture webhook_events)
TABLE_TOKEN_SECRET=...                          # 32+ caractères aléatoires
PAYMENT_SECRET_BANKILY=...
PAYMENT_SECRET_MASRIVI=...
PAYMENT_SECRET_SEDAD=...
PAYMENT_SECRET_CLICK=...

# Recommandé en production
UPSTASH_REDIS_REST_URL=...
UPSTASH_REDIS_REST_TOKEN=...
NEXT_PUBLIC_SITE_URL=https://cafe-dugout.vercel.app
```

Générer un secret : `openssl rand -base64 48`.

---

## Annexe C — Équivalents FastAPI (si un backend Python est ajouté)

Le projet livré est **100 % Next.js** (pas de FastAPI, pas de Firebase) : les routes
`/api/*` jouent le rôle du backend. Si vous ajoutez plus tard un service Python
(rapports, intégration comptable), voici les équivalents directs.

**Validation (Pydantic v2)** :

```python
from pydantic import BaseModel, Field, ConfigDict
from typing import Literal

class OrderItem(BaseModel):
    model_config = ConfigDict(extra="forbid")        # ← équivalent de Zod .strict()
    menu_item_id: str = Field(pattern=r"^[0-9a-f-]{36}$")
    qty: int = Field(ge=1, le=20)
    note: str | None = Field(default=None, max_length=140)

class OrderIn(BaseModel):
    model_config = ConfigDict(extra="forbid")
    table: str | None = Field(default=None, pattern=r"^(T(0[1-9]|1[0-9]|20)|EMP)$")
    qr_token: str | None = Field(default=None, min_length=8, max_length=64)
    items: list[OrderItem] = Field(min_length=1, max_length=30)
    client_ref: str = Field(pattern=r"^[0-9a-f-]{36}$")
```

**Rate limiting** (slowapi) :

```python
from slowapi import Limiter
from slowapi.util import get_remote_address
limiter = Limiter(key_func=get_remote_address)

@app.post("/api/orders")
@limiter.limit("20/minute")
async def create_order(request: Request, order: OrderIn):
    ...
```

**Webhook signé** :

```python
import hmac, hashlib

def verify(raw_body: bytes, timestamp: str, signature: str, secret: str) -> bool:
    if abs(time.time() - int(timestamp)) > 300:
        return False
    expected = hmac.new(secret.encode(), f"{timestamp}.".encode() + raw_body,
                        hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature)   # ← temps constant
```

Le reste (idempotence, montants, RBAC) reste **en base** : c'est le seul endroit où
l'ensemble des clients — Next.js, FastAPI, script, curl — est contrôlé de la même façon.

---

## Fichiers ajoutés ou modifiés par cet audit

| Fichier | Rôle |
|---|---|
| `next-app/lib/security/schemas.js` | validation Zod (commande, connexion, webhook, jeton) |
| `next-app/lib/security/rate-limit.js` | limiteur mémoire + Redis, en-têtes `RateLimit-*` |
| `next-app/lib/security/rbac.js` | matrice de permissions, `requirePermission`, `guardApi` |
| `next-app/lib/security/signature.js` | HMAC temps constant + fenêtre anti-rejeu, 4 opérateurs |
| `next-app/lib/security/qr.js` | jetons de table signés (TTL, nonce, HMAC) |
| `next-app/lib/security/http.js` | IP réelle, JSON normalisé, anti-CSRF, erreurs propres |
| `next-app/lib/security/env-check.js` | contrôle des secrets au démarrage |
| `next-app/lib/supabase/admin.js` | client `service_role` serveur uniquement |
| `next-app/lib/supabase/anon.js` | client public pour les appels serveur |
| `next-app/lib/offline/outbox.js` | file IndexedDB, backoff, synchro auto |
| `next-app/app/api/orders/route.js` | création de commande durcie |
| `next-app/app/api/payments/webhook/[provider]/route.js` | webhooks signés + idempotence |
| `next-app/app/api/table/session/route.js` | décodage des jetons de table |
| `next-app/app/api/stats/route.js` | exemple de route admin protégée |
| `next-app/middleware.js` | plafond API, taille max, session |
| `next-app/components/client/ClientMenu.js` | envoi via `/api/orders`, file hors-ligne, `?s=` |
| `next-app/components/pos/PosApp.js` | onglets filtrés par rôle |
| `next-app/.env.local.example` | variables complètes (public / serveur) |
| `supabase/4_security_hardening.sql` | idempotence, débit, intents, webhooks, droits |
| `security-test.mjs` / `rbac-test.mjs` | non-régression (35 tests) |
