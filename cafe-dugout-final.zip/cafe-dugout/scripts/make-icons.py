#!/usr/bin/env python3
"""Redimensionne le logo fourni pour les icônes PWA, sans le redessiner."""
from pathlib import Path
from PIL import Image, ImageOps
OUT = Path(__file__).resolve().parent.parent / 'public'
source = Image.open(OUT / 'brand/logo.jpg').convert('RGB')
for size, name in ((192, 'icon-192.png'), (512, 'icon-512.png'), (180, 'apple-touch-icon.png'), (64, 'favicon.png')):
    ImageOps.contain(source, (size, size), Image.Resampling.LANCZOS).save(OUT / name)
canvas = Image.new('RGB', (512, 512), '#002e25')
icon = ImageOps.contain(source, (354, 354), Image.Resampling.LANCZOS)
canvas.paste(icon, ((512-icon.width)//2, (512-icon.height)//2))
canvas.save(OUT / 'icon-maskable-512.png')
print('Icônes Café DUGOUT générées dans', OUT)
